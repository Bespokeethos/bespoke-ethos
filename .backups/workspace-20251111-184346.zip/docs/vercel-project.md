Vercel Production Project
-------------------------

- Project ID: prj_444RgNkeGtkyGFSdm59T1hSwjz0F
- Project Name: basehub-marketing-website (production)
- Domains: bespokeethos.com, www.bespokeethos.com (attach in Settings → Domains)

Recent failure snapshot
- Build command: `pnpm run build`
- Error: exited with code 1 (see Vercel build logs for details)
- Suggested next steps: ensure env vars exist and rerun deploy from `main`.

