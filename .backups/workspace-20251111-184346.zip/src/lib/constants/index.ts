export const siteHost =
  process.env.VERCEL_PROJECT_PRODUCTION_URL || "nextjs-marketing-website.basehub.com";
export const siteUrl = `https://${siteHost}`;